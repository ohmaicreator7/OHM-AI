# Model Folder

This will contain AI model files and notes.