## OHM Vision

Open source AI model to express talent and voice.